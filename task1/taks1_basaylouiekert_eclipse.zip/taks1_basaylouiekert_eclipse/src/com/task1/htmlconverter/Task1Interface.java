package com.task1.htmlconverter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

/**
 * @author Louie Kert Basay
 * @date
 * 
 */
@SuppressWarnings("serial")
public class Task1Interface extends JPanel {
	
	private JFileChooser fc;
	private JButton openHtml, saveCsv;
	private JLabel authorLabel, titleLabel, dateLabel;
	private JTextArea contentArea;
	private HtmlExtractor extractor;
	private CsvMaker maker;
	private static final String username = System.getProperty("user.name");
	private static final String savePath = "C:\\Users\\" + username + "\\Documents\\Csv Files\\";
	
	public Task1Interface() {
		JFrame frame = new JFrame("Task 1\\Louie Kert Basay");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(new Dimension(650, 600));
		
		fc = new JFileChooser();
		
		JPanel buttonPanel = new JPanel();
		JPanel authorPanel = new JPanel();
		JPanel titlePanel = new JPanel();
		JPanel contentPanel = new JPanel();
		JPanel datePanel = new JPanel();
		//JScrollBar scrollBar = new JScrollBar(JScrollBar.HORIZONTAL);
		
		
		//button to open html file
		openHtml = new JButton("Open Html File");
		openHtml.addActionListener(new ButtonListener());
		
		//button to save to csv file
		saveCsv = new JButton("Save to Csv File");
		saveCsv.addActionListener(new ButtonListener());
		
		//label for author
		authorLabel = new JLabel();
		authorLabel.setPreferredSize(new Dimension(500, 100));
		authorLabel.setText("Author: ");
		authorLabel.setOpaque(true);
		
		//label for title
		titleLabel = new JLabel();
		titleLabel.setPreferredSize(new Dimension(500, 100));
		titleLabel.setText("NewsTitle: ");
		titleLabel.setOpaque(true);
		
		//text area for the contents
		contentArea = new JTextArea();
		contentArea.setPreferredSize(new Dimension(500, 100));
		contentArea.setText("Contents: \n");
		contentArea.setEditable(false);
		contentArea.setLineWrap(true);
		contentArea.setWrapStyleWord(true);
		contentArea.setOpaque(true);
		
		//label for date
		dateLabel = new JLabel();
		dateLabel.setPreferredSize(new Dimension(500, 100));
		dateLabel.setText("Date: ");
		dateLabel.setOpaque(true);
		
		//add button to a panel
		buttonPanel.add(openHtml);
		//buttonPanel.add(saveCsv);
		buttonPanel.setPreferredSize(new Dimension(500, 100));
		buttonPanel.setOpaque(false);
		
		//add author to a panel
		authorPanel.add(authorLabel);
		authorPanel.setPreferredSize(new Dimension(500, 100));
		authorPanel.setOpaque(false);
		
		//add title to a panel
		titlePanel.add(titleLabel);
		titlePanel.setPreferredSize(new Dimension(500, 100));
		titlePanel.setOpaque(false);
		
		//add content to a panel
		contentPanel.add(contentArea);
		contentPanel.setPreferredSize(new Dimension(500, 100));
		contentPanel.setBackground(Color.GRAY);
		contentPanel.setOpaque(false);
		
		//add date to a panel
		datePanel.add(dateLabel);
		datePanel.setPreferredSize(new Dimension(500, 100));
		datePanel.setOpaque(false);
		
		//add all panel to a main panel
		add(buttonPanel);
		add(authorPanel);
		add(titlePanel);
		add(contentPanel);
		add(datePanel);
		
		frame.getContentPane().add(this);
		//frame.pack();
		frame.setVisible(true);
	}
	
	private class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == openHtml) {
				int returnVal = fc.showOpenDialog(Task1Interface.this);
	
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();
					String fileName = file.getName();	
					try {
						extractor = new HtmlExtractor("file:///" + file.getAbsolutePath());
						authorLabel.setText("Author: " + extractor.retrieveNewsAuthor());
						titleLabel.setText("Title: " + extractor.retrieveNewsTitle());
						contentArea.append(extractor.retrieveNewsContents());
						dateLabel.setText("Date: " + extractor.retrieveNewsDate());
						//save Csv to csv file
						new File(savePath).mkdir();
						maker = new CsvMaker(savePath + fileName + ".csv", "file:///" + file.getAbsolutePath());
						maker.createFile();
					}
					catch(Exception err) {
						err.printStackTrace();
					}
				}
			}
		}
	}
	
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new Task1Interface();
			}
		});
	}
}
