package com.task1.htmlconverter;

/**
 * 
 * @author Louie Kert Basay
 * @date 07-03-13
 */

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.html.*;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.net.URL;
import java.util.logging.Level;

public class HtmlExtractor {
	
	//fields
	private HtmlPage page; 
	private final WebClient client = new WebClient(BrowserVersion.CHROME);
	
	//constructor
	public HtmlExtractor(String url) throws Exception {
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
		client.getOptions().setCssEnabled(false);
		client.getOptions().setJavaScriptEnabled(false);
		client.getOptions().setThrowExceptionOnFailingStatusCode(false);
		client.getOptions().setThrowExceptionOnScriptError(false);
		page = (HtmlPage) client.getPage(url);
	}
	
	public HtmlExtractor(URL url) throws Exception{
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
		client.getOptions().setCssEnabled(false);
		client.getOptions().setJavaScriptEnabled(false);
		client.getOptions().setThrowExceptionOnFailingStatusCode(false);
		client.getOptions().setThrowExceptionOnScriptError(false);
		page = (HtmlPage) client.getPage(url);
	}
	
	/*
	 * 		End of constructors
	 */
	
	
	public final String retrieveNewsTitle() {
		final DomElement target = page.getFirstByXPath("//h1");
		return (String) target.getTextContent();
	}
	
	public final String retrieveNewsDate() {
		final DomElement target = page.getFirstByXPath("//p");
		return target.getTextContent();
	}
	
	@SuppressWarnings("unchecked")
	public final String retrieveNewsContents() {
		StringBuilder target = new StringBuilder();
		final ArrayList<DomElement> contents = (ArrayList<DomElement>) page.getByXPath("//p");
		for(DomElement tmp : contents) {
			if(!tmp.getTextContent().equals(this.retrieveNewsDate())) {
				target.append(tmp.getTextContent() + "\n");
				if(tmp.getTextContent().contains(this.retrieveNewsAuthor()))
					break;
			}
		}
		
		//delete the name of the author in the news content using the delete method of the StringBuilder
		target.delete(target.length() - (this.retrieveNewsAuthor().length() + 2) - 2, target.length() - 1);
		return target.toString();
	}
	
	public final ArrayList<String> retrieveUniqueWords() {
		ArrayList<String> lst = new ArrayList<String> ();
		String content = this.retrieveNewsContents();
		StringTokenizer st = new StringTokenizer(content);	//split string by space
		while(st.hasMoreElements()) {
			String tmp = st.nextElement().toString();
			if(!lst.contains(tmp))
				lst.add(tmp);
		}
		return lst;
	}
	
	public final int countUniqueWords() {
		ArrayList<String> lst = this.retrieveUniqueWords();
		return lst.size();
	}
	
	public final String retrieveNewsAuthor() {
		final DomElement target = page.getFirstByXPath("//b");
		String str = target.getTextContent();
		return str.substring(1, str.length() - 1);
	}
	
	protected final String getPageAsText() {
		return page.asText();
	}
	
	public final void endWebClient() {
		client.closeAllWindows();
	}
}
