package com.task1.htmlconverter;

/**
 * @author Louie Kert Basay
 * @date 07-07-13
 * 
 */

import au.com.bytecode.opencsv.CSVWriter;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.util.StringTokenizer;

public class CsvMaker {
	
	//fields
	CSVWriter writer;
	HtmlExtractor extractor;
	
	//constructor
	public CsvMaker(String resultFile, String htmlFile) throws Exception {
		BufferedWriter out = new BufferedWriter(new FileWriter(resultFile));
		extractor = new HtmlExtractor(htmlFile);
		writer = new CSVWriter(out);
	}
	
	/*
	 * 		End of constructors
	 */
	
	public void createFile() throws Exception {
		this.addNewsTitle();
		this.addNewsDate();
		this.addNewsAuthor();
		this.addNewsContents();
		writer.close();
		extractor.endWebClient();
	}
	
	public void addNewsDate() {
		String query = extractor.retrieveNewsDate();
		StringTokenizer st = new StringTokenizer(query);
		String[] tmp = new String[st.countTokens()];
		for(int i = 0; st.hasMoreElements(); i++)
			tmp[i] = st.nextElement().toString();
		writer.writeNext(tmp);
	}
	
	public void addNewsAuthor() {
		String query = extractor.retrieveNewsAuthor();
		StringTokenizer st = new StringTokenizer(query);
		String[] tmp = new String[st.countTokens()];
		for(int i = 0; st.hasMoreElements(); i++)
			tmp[i] = st.nextElement().toString();
		writer.writeNext(tmp);
	}
	
	public void addNewsTitle() {
		String query = extractor.retrieveNewsTitle();
		StringTokenizer st = new StringTokenizer(query);
		String[] tmp = new String[st.countTokens()];
		for(int i = 0; st.hasMoreElements(); i++)
			tmp[i] = st.nextElement().toString();
		writer.writeNext(tmp);
	}
	
	public void addNewsContents() {
		String query = extractor.retrieveNewsContents();
		StringTokenizer st = new StringTokenizer(query);
		String[] tmp = new String[st.countTokens()];
		for(int i = 0; st.hasMoreElements(); i++)
			tmp[i] = st.nextElement().toString();
		writer.writeNext(tmp);
	}

}
